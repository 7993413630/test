from django.contrib import admin
from .models import CarParkingSpace

admin.site.register(CarParkingSpace)
